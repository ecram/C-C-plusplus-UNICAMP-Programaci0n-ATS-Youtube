#___ <stdio.h>
int main()
___
   int a____;
   float ___=2.1;
   long ___ x=23.1L;
   printf(“a=%d\n”,___);
   printf(“y=%f\n”,y);
   printf(“x=%Ld\n”___ x)___
    ____;
}
