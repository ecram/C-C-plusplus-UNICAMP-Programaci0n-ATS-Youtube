#include <stdio.h>
____________________
{
   printf("Bom dia\n")___
   return___;
___
