#include <stdio.h>
int main()
int main()
   int a=10;
   float y=2.1;
   long double x=23.1L;
   printf(“a=%d\n”,___);
   printf(“y=%f\n”,y);
   printf(“x=%LF\n”___ x)___
   return 0;
}
