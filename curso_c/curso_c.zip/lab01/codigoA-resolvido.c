#include <stdio.h>
int main()
{
   printf("Bom dia\n");
   return 0;
}
