#include <stdio.h>
int main()
{
   // imprime meu nome
    printf("Carlos\n");
    return 0;
}
