typedef enum { verde, vermelho, azul } tcores;

int parImpar(int num);
int somatorio(int num);
int fatorial(int num);
void saltoPara(int inicio, int fim, int salta, int para );
void imprima_cor( tcores cor );
