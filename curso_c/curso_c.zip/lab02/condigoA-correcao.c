#include <stdio.h>
int main()
{
   int vetor[] = { 1,2,3,4,5 };
   float precos[4]= {1.99,2.99,19.99,199.99};
   char string[16]="Introdução ao C";
   struct data { int dia, mes, ano; } hoje = {.dia=20, .mes=2, .ano=2014};
   enum cores { verde, vermelho, azul };
   return 0;
}

