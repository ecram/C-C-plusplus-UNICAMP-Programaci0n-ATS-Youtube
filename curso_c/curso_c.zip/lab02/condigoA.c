#include <stdio.h>
int main()
{
   int vetor = { 1,2,3,4,5 };
   float precos[2]= {1.99 2.99 19.99 199.99}
   char string[15]="Introdução ao C";
   struct data { dia, mes, ano } = {.dia=20, .mes=2, .ano=2014};
   cores { verde, vermelho, azul };
   return 0;
}

