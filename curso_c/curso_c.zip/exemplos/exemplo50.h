/* 
 * nome: exemplo50.h
 * descrição: ponteiros como parâmetros de função
 * data: 06/11/2012
 */
void inc(int *x)
{
   (*x)++;
}
void dec(int *x)
{
   (*x)--;
}

