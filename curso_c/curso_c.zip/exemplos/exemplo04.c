#include <stdio.h>
int main()
{
   short int km;
    unsigned short int idade;
    long int cm;
    unsigned long int saldo_cc;
    long long int mm;
    unsigned long long int moleculas;
    return 0;
}
