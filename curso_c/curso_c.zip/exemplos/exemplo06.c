/* 
 * nome: exemplo06.c
 * descrição: Declaração de variáveis ponto flutuante.
 * data: 08/04/2013
 */
#include <stdio.h>
int main()
{
   float km;
    double cm;
    long double mm;
    return 0;
}
