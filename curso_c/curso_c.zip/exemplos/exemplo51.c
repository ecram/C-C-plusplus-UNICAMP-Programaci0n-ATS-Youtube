/* 
 * nome: exemplo51.c
 * descrição: 
 * data: 06/11/2012
 */
int variavel=21;
