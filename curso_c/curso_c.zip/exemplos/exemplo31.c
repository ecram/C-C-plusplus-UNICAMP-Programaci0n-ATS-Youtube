/* 
 * nome: exemplo31.c
 * descrição: Blocos em C
 * data: 06/11/2012
 */
#include <stdio.h>
int main()
{
    printf("Bom dia\n");
    {
       printf("Dentro do bloco\n");
    }
    return 0;
}

