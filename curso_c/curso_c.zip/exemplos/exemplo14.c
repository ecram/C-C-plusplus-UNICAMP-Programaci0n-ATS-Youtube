/* 
 * nome: exemplo14.c
 * descrição: Declaração de struct
 * data: 03/10/2012
 */
#include <stdio.h>
int main()
{
   struct data
    {
       int dia,mes,ano;
    } hoje;
    struct data amanha;
    return 0;
}

