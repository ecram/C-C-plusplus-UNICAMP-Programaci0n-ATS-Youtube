/* 
 * nome: exemplo52.c
 * descrição: 
 * data: 03/10/2012
 */
#include <stdio.h> 

extern int variavel; 
int main(){ 
    printf("variavel externa=%d\n",variavel);
    return 0;
} 

