/* 
 * nome: exemplo42.c
 * descrição: declaração de funções
 * data: 10/04/2013
 */
void inc(int x)
{
   x++;
}
void dec(int x)
{
   x--;
}
int sum(int x, int y)
{
   return x + y;
}
int sub(int x, int y)
{
   return x - y;
}

