/* 
 * nome: exemplo10.c
 * descrição: Declaração de vetores e matrizes
 * data: 03/10/2012
 */
#include <stdio.h>
int main()
{
    int idade;
    int dataNascimento[3];
    int matriz2D[10][10], matriz3D[10][10][10];
    return 0;
}
