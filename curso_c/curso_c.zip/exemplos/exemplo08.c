/* 
 * nome: exemplo08.c
 * descrição: Declaração de variáveis caractere.
 * data: 03/10/2012
 */
#include <stdio.h>
#include <stdlib.h>
int main()
{
    char letra;
    unsigned char nota;
    wchar_t utf;
    return 0;
}
