/* 
 * nome: exemplo03.c
 * descrição: Declaração e inicialização de variáveis
 * data: 11/02/2014
 */
#include <stdio.h>
int main()
{
   // Declaração e inicialização de variáveis
    int contador=0;
    int x=1,y=1;
    char c;
    c='x';
    // imprime Bom dia
    printf("Bom dia\n");
    printf("contador=%d\n",contador);
    printf("x=%d, y=%d\n",x,y);
    printf("c=%c\n",c);
    return 0;
}
