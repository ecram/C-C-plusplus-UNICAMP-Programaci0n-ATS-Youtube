/* 
 * nome: exemplo07.c
 * descrição: Declaração de variáveis inteiras
 * data: 03/10/2012
 */
#include <stdio.h>
int main()
{
    printf("float = %lu\n", sizeof(float));
    printf("double = %lu\n", sizeof(double));
    printf("long double = %lu\n", sizeof(long double));
    return 0;
 }
