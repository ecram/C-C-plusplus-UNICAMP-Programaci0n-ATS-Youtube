/* 
 * nome: exemplo09.c
 * descrição: Declaração de variáveis inteiras
 * data: 03/10/2012
 */
#include <stdio.h>
#include <stdlib.h>
int main()
{
    printf("char = %lu\n", sizeof(char));
    printf("unsigned char = %lu\n", sizeof(unsigned char));
    printf("wchar_t = %lu\n", sizeof(wchar_t));
    return 0;
}
