/* 
 * nome: exemplo41.h
 * descrição: declaração de funções
 * data: 06/11/2012
 */
void inc(int x);
void dec(int );
int sum(int x, int y);
int sub(int, int);

