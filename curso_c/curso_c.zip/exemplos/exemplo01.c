/* 
 * nome: exemplo01.c
 * descrição: primeiro exemplo em C
 * data: 17/08/2012
 */
#include <stdio.h>
int main()
{
   // imprime Bom dia
    printf("Bom dia\n");
    return 0;
}
