
void acumulador(int num);
