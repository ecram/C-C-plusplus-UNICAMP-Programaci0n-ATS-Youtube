#include <stdio.h>
#include "lab04e.h"

int main()
{
	acumulador(1);
	acumulador(10);
	acumulador(-100);
	return 0;
}
